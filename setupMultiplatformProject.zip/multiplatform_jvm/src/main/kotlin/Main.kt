fun main(args:Array<String>){
	println("JVM4")
}